local addonName, ns = ...

ns.minimapTransforms = {
    [50811] = { offsetX = 0.0190, offsetY = -0.1230, scale = 0.6200, scaleX = 1.0000, scaleY = 0.7250, lineThickness = 1.0000 },
    [50816] = { offsetX = 0.1800, offsetY = 0.1750, scale = 0.7850, scaleX = 0.7250, scaleY = 0.6100, lineThickness = 1.0000 },
    [50817] = { offsetX = -0.1100, offsetY = 0.0350, scale = 0.9300, scaleX = 0.7400, scaleY = 0.5900, lineThickness = 1.0000 },
    [50818] = { offsetX = -0.0380, offsetY = -0.0760, scale = 0.7200, scaleX = 0.7600, scaleY = 0.8000, lineThickness = 1.0000 },
    [50820] = { offsetX = -0.0120, offsetY = 0.1610, scale = 0.5650, scaleX = 0.9000, scaleY = 0.9400, lineThickness = 1.0000 },
    [50821] = { offsetX = 0.1080, offsetY = -0.1220, scale = 0.5200, scaleX = 0.8200, scaleY = 1.0100, lineThickness = 1.0000 },
    [50822] = { offsetX = -0.1260, offsetY = 0.0470, scale = 1.2050, scaleX = 0.3650, scaleY = 0.3400, lineThickness = 1.0000 },
    [66522] = { offsetX = -0.1200, offsetY = -0.1000, scale = 0.3100, scaleX = 1.1400, scaleY = 1.0000, lineThickness = 1.0000 },
}
