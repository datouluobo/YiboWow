local addonName, ns = ...
local YBP = _G.YiboBeastPaths

local HBD = LibStub and LibStub("HereBeDragons-2.0", true)
local TWO_PI = math.pi * 2
local sqrt = math.sqrt
local min = math.min
local max = math.max
local sin = math.sin
local cos = math.cos
local floor = math.floor

local minimapState = {
    cacheBuilt = false,
    routesByMap = {},
    segmentPool = {},
    activeCount = 0,
    lastSignature = nil,
}

local MINIMAP_ROUTE_CLIP_RADIUS = 1.03
local MINIMAP_ROUTE_LINE_THICKNESS = 3
local MINIMAP_ROUTE_SEGMENT_STEP_PX = 1
local MINIMAP_ROUTE_SEGMENT_OVERLAP_PX = 2

local minimapSizes = {
    indoor = {
        [0] = 300,
        [1] = 240,
        [2] = 180,
        [3] = 120,
        [4] = 80,
        [5] = 50,
    },
    outdoor = {
        [0] = 466 + 2 / 3,
        [1] = 400,
        [2] = 333 + 1 / 3,
        [3] = 266 + 2 / 6,
        [4] = 200,
        [5] = 133 + 1 / 3,
    },
}

local function Atan2(y, x)
    if math.atan2 then
        return math.atan2(y, x)
    end

    if x > 0 then
        return math.atan(y / x)
    elseif x < 0 and y >= 0 then
        return math.atan(y / x) + math.pi
    elseif x < 0 and y < 0 then
        return math.atan(y / x) - math.pi
    elseif y > 0 then
        return math.pi * 0.5
    elseif y < 0 then
        return -math.pi * 0.5
    end

    return 0
end

local function NormalizeAngle(angle)
    while angle > math.pi do
        angle = angle - TWO_PI
    end

    while angle < -math.pi do
        angle = angle + TWO_PI
    end

    return angle
end

local function HideAllMinimapSegments()
    minimapState.activeCount = 0
    for _, slot in ipairs(minimapState.segmentPool) do
        slot:Hide()
    end
end

local function GetMinimapRadius()
    if C_Minimap and C_Minimap.GetViewRadius then
        return C_Minimap.GetViewRadius()
    end

    if not Minimap or not Minimap.GetZoom then
        return nil
    end

    local zoom = Minimap:GetZoom()
    local cvarZoom = tonumber(GetCVar("minimapZoom")) or zoom
    local mode = (cvarZoom == zoom) and "outdoor" or "indoor"
    local radius = minimapSizes[mode] and minimapSizes[mode][zoom]
    if radius then
        return radius * 0.5
    end
end

local function BuildSegmentCache(petID, route)
    local segments = route and route.segments
    if type(segments) ~= "table" then
        return nil
    end

    local built = {}
    local color = route.color or { 0.15, 0.95, 0.85, 0.90 }
    local transform = ns.routeTransforms and ns.routeTransforms[petID] or nil
    local scale = transform and transform.scale or 1.0
    local scaleX = transform and transform.scaleX or 1.0
    local scaleY = transform and transform.scaleY or 1.0
    local offsetX = transform and transform.offsetX or 0.0
    local offsetY = transform and transform.offsetY or 0.0

    local function TransformPoint(point)
        local x = point and point.x
        local y = point and point.y
        if type(x) ~= "number" or type(y) ~= "number" then
            return nil
        end

        return {
            mapX = 0.5 + offsetX + ((x - 0.5) * scale * scaleX),
            mapY = 0.5 + offsetY + ((y - 0.5) * scale * scaleY),
        }
    end

    for segmentIndex, segment in ipairs(segments) do
        local points = segment.points
        if type(points) == "table" and #points >= 2 then
            for pointIndex = 1, (#points - 1) do
                local startPoint = TransformPoint(points[pointIndex])
                local endPoint = TransformPoint(points[pointIndex + 1])
                if startPoint and endPoint then
                    built[#built + 1] = {
                        petID = petID,
                        mapID = route.mapID,
                        segmentIndex = segmentIndex,
                        pointIndex = pointIndex,
                        color = color,
                        startPoint = startPoint,
                        endPoint = endPoint,
                    }
                end
            end

            if segment.loop and #points >= 3 then
                local startPoint = TransformPoint(points[#points])
                local endPoint = TransformPoint(points[1])
                if startPoint and endPoint then
                    built[#built + 1] = {
                        petID = petID,
                        mapID = route.mapID,
                        segmentIndex = segmentIndex,
                        pointIndex = #points,
                        color = color,
                        startPoint = startPoint,
                        endPoint = endPoint,
                    }
                end
            end
        end
    end

    return built
end

local function EnsureRouteCache()
    if minimapState.cacheBuilt then
        return
    end

    wipe(minimapState.routesByMap)

    for petID, route in pairs(ns.curatedRoutes or {}) do
        if route and route.mapID then
            local builtSegments = BuildSegmentCache(petID, route)
            if builtSegments and #builtSegments > 0 then
                minimapState.routesByMap[route.mapID] = minimapState.routesByMap[route.mapID] or {}
                minimapState.routesByMap[route.mapID][#minimapState.routesByMap[route.mapID] + 1] = {
                    petID = petID,
                    mapID = route.mapID,
                    color = route.color,
                    segments = builtSegments,
                }
            end
        end
    end

    for _, routes in pairs(minimapState.routesByMap) do
        table.sort(routes, function(a, b)
            return a.petID < b.petID
        end)
    end

    minimapState.cacheBuilt = true
end

local function AcquireSegmentSlot()
    local index = minimapState.activeCount + 1
    local slot = minimapState.segmentPool[index]
    if not slot then
        slot = CreateFrame("Frame", nil, minimapState.overlay)
        slot:SetSize(16, 16)
        slot:SetFrameStrata("DIALOG")
        slot:SetFrameLevel((minimapState.overlay:GetFrameLevel() or 1) + 20)
        slot:EnableMouse(false)

        slot.line = slot:CreateTexture(nil, "OVERLAY")
        slot.line:SetTexture("Interface\\Buttons\\WHITE8X8")
        slot.line:SetBlendMode("BLEND")

        minimapState.segmentPool[index] = slot
    end

    minimapState.activeCount = index
    return slot
end

local function TrimUnusedSegmentSlots()
    for index = minimapState.activeCount + 1, #minimapState.segmentPool do
        minimapState.segmentPool[index]:Hide()
    end
end

local function ClipLineToCircle(x1, y1, x2, y2, radius)
    local r2 = radius * radius
    local inside1 = (x1 * x1 + y1 * y1) <= r2
    local inside2 = (x2 * x2 + y2 * y2) <= r2
    if inside1 and inside2 then
        return x1, y1, x2, y2
    end

    local dx = x2 - x1
    local dy = y2 - y1
    local a = dx * dx + dy * dy
    if a <= 0 then
        return nil
    end

    local b = 2 * (x1 * dx + y1 * dy)
    local c = x1 * x1 + y1 * y1 - r2
    local disc = b * b - 4 * a * c
    if disc < 0 then
        return nil
    end

    local root = sqrt(disc)
    local t1 = (-b - root) / (2 * a)
    local t2 = (-b + root) / (2 * a)
    if t1 > t2 then
        t1, t2 = t2, t1
    end

    local startT = max(0, t1)
    local endT = min(1, t2)
    if startT > endT then
        return nil
    end

    return x1 + dx * startT, y1 + dy * startT, x1 + dx * endT, y1 + dy * endT
end

local function GetRouteTransformContext()
    if not HBD or not Minimap or not Minimap:IsVisible() then
        return nil
    end

    local playerX, playerY, instanceID = HBD:GetPlayerWorldPosition()
    local currentMapID = HBD:GetPlayerZone()
    local radius = GetMinimapRadius()
    if not playerX or not playerY or not instanceID or not currentMapID or not radius or radius <= 0 then
        return nil
    end

    local halfWidth = (Minimap:GetWidth() or 0) * 0.5
    local halfHeight = (Minimap:GetHeight() or 0) * 0.5
    if halfWidth <= 0 or halfHeight <= 0 then
        return nil
    end

    local rotate = (GetCVar("rotateMinimap") == "1")
    local facing = rotate and GetPlayerFacing() or 0
    if rotate and not facing then
        return nil
    end

    local mapSin = rotate and sin(facing) or 0
    local mapCos = rotate and cos(facing) or 1

    return {
        currentMapID = currentMapID,
        playerWorldX = playerX,
        playerWorldY = playerY,
        instanceID = instanceID,
        radius = radius,
        halfWidth = halfWidth,
        halfHeight = halfHeight,
        rotate = rotate,
        facing = facing or 0,
        mapSin = mapSin,
        mapCos = mapCos,
    }
end

local function ToMinimapNormalizedFromMapPoint(point, playerMapX, playerMapY, zoneWidth, zoneHeight, context)
    local xDist = zoneWidth * ((point.mapX or 0) - playerMapX)
    local yDist = zoneHeight * ((point.mapY or 0) - playerMapY)

    if context.rotate then
        local dx = xDist
        local dy = yDist
        xDist = dx * context.mapCos - dy * context.mapSin
        yDist = dx * context.mapSin + dy * context.mapCos
    end

    return xDist / context.radius, yDist / context.radius
end

local function UpdateSegmentSlot(slot, startX, startY, endX, endY, color)
    local r = color[1] or 1
    local g = color[2] or 1
    local b = color[3] or 1
    local a = color[4] or 0.9
    local dx = endX - startX
    local dy = endY - startY
    local length = sqrt(dx * dx + dy * dy)
    if length < 0.5 then
        slot:Hide()
        return false
    end

    if MINIMAP_ROUTE_SEGMENT_OVERLAP_PX > 0 and length > 0 then
        local nx = dx / length
        local ny = dy / length
        startX = startX - (nx * MINIMAP_ROUTE_SEGMENT_OVERLAP_PX)
        startY = startY - (ny * MINIMAP_ROUTE_SEGMENT_OVERLAP_PX)
        endX = endX + (nx * MINIMAP_ROUTE_SEGMENT_OVERLAP_PX)
        endY = endY + (ny * MINIMAP_ROUTE_SEGMENT_OVERLAP_PX)
        dx = endX - startX
        dy = endY - startY
        length = sqrt(dx * dx + dy * dy)
    end

    local centerX = (startX + endX) * 0.5
    local centerY = (startY + endY) * 0.5
    local angle = NormalizeAngle(Atan2(dy, dx))

    slot:ClearAllPoints()
    slot:SetPoint("CENTER", minimapState.overlay, "CENTER", centerX, centerY)
    slot.line:ClearAllPoints()
    slot.line:SetPoint("CENTER", slot, "CENTER", 0, 0)
    slot.line:SetSize(length + 1, MINIMAP_ROUTE_LINE_THICKNESS)
    slot.line:SetRotation(angle)
    slot.line:SetVertexColor(r, g, b, min(max(a, 0.96), 0.99))

    slot:Show()
    return true
end

local function BuildRefreshSignature(context)
    local facingBucket = context.rotate and math.floor(((context.facing or 0) * 180 / math.pi) + 0.5) or 0
    return table.concat({
        tostring(context.currentMapID),
        tostring(context.instanceID),
        string.format("%.1f", context.playerWorldX),
        string.format("%.1f", context.playerWorldY),
        tostring(Minimap:GetZoom() or 0),
        tostring(facingBucket),
        tostring(GetCVar("rotateMinimap") or "0"),
        string.format("%.1f", context.radius),
    }, ":")
end

local function ResolveActiveRouteMapID(currentMapID)
    local mapID = currentMapID
    while mapID do
        if minimapState.routesByMap[mapID] then
            return mapID
        end

        if not C_Map or not C_Map.GetMapInfo then
            break
        end

        local info = C_Map.GetMapInfo(mapID)
        mapID = info and info.parentMapID or nil
    end
end

function YBP:InitializeMinimapRenderer()
    if minimapState.initialized or not Minimap then
        return
    end

    minimapState.overlay = CreateFrame("Frame", nil, Minimap)
    minimapState.overlay:SetAllPoints(Minimap)
    minimapState.overlay:SetFrameStrata("DIALOG")
    minimapState.overlay:SetFrameLevel((Minimap:GetFrameLevel() or 1) + 15)
    minimapState.overlay:EnableMouse(false)

    minimapState.updateFrame = CreateFrame("Frame")
    minimapState.updateFrame.elapsed = 0
    minimapState.updateFrame:SetScript("OnEvent", function()
        if YBP.RefreshMinimapLayer then
            YBP:RefreshMinimapLayer(true)
        end
    end)
    minimapState.updateFrame:SetScript("OnUpdate", function(_, elapsed)
        minimapState.updateFrame.elapsed = minimapState.updateFrame.elapsed + elapsed
        if minimapState.updateFrame.elapsed < 0.05 then
            return
        end

        minimapState.updateFrame.elapsed = 0
        if YBP.RefreshMinimapLayer then
            YBP:RefreshMinimapLayer()
        end
    end)
    minimapState.updateFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    minimapState.updateFrame:RegisterEvent("ZONE_CHANGED")
    minimapState.updateFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    minimapState.updateFrame:RegisterEvent("ZONE_CHANGED_INDOORS")
    minimapState.updateFrame:RegisterEvent("MINIMAP_UPDATE_ZOOM")
    minimapState.updateFrame:RegisterEvent("CVAR_UPDATE")

    minimapState.initialized = true
end

function YBP:RefreshMinimapLayer(force)
    if not minimapState.initialized then
        return
    end

    if not self.db or not self.db.visible then
        minimapState.lastSignature = nil
        HideAllMinimapSegments()
        return
    end

    EnsureRouteCache()

    local context = GetRouteTransformContext()
    if not context then
        minimapState.lastSignature = nil
        HideAllMinimapSegments()
        return
    end

    local signature = BuildRefreshSignature(context)
    if not force and signature == minimapState.lastSignature then
        return
    end
    minimapState.lastSignature = signature

    local activeRouteMapID = ResolveActiveRouteMapID(context.currentMapID)
    local routes = activeRouteMapID and minimapState.routesByMap[activeRouteMapID] or nil
    if not routes or #routes == 0 then
        HideAllMinimapSegments()
        return
    end

    minimapState.activeCount = 0
    local playerMapX, playerMapY = HBD:GetZoneCoordinatesFromWorldInstance(
        context.playerWorldX,
        context.playerWorldY,
        context.instanceID,
        activeRouteMapID,
        true
    )
    local zoneWidth, zoneHeight = HBD:GetZoneSize(activeRouteMapID)
    if not playerMapX or not playerMapY or not zoneWidth or not zoneHeight or zoneWidth <= 0 or zoneHeight <= 0 then
        HideAllMinimapSegments()
        return
    end

    for _, route in ipairs(routes) do
        for _, segment in ipairs(route.segments) do
            local nx1, ny1 = ToMinimapNormalizedFromMapPoint(segment.startPoint, playerMapX, playerMapY, zoneWidth, zoneHeight, context)
            local nx2, ny2 = ToMinimapNormalizedFromMapPoint(segment.endPoint, playerMapX, playerMapY, zoneWidth, zoneHeight, context)
            local cx1, cy1, cx2, cy2 = ClipLineToCircle(nx1, ny1, nx2, ny2, MINIMAP_ROUTE_CLIP_RADIUS)
            if cx1 and cy1 and cx2 and cy2 then
                local startX = cx1 * context.halfWidth
                local startY = -cy1 * context.halfHeight
                local endX = cx2 * context.halfWidth
                local endY = -cy2 * context.halfHeight
                local dx = endX - startX
                local dy = endY - startY
                local pixelLength = sqrt(dx * dx + dy * dy)
                local steps = max(1, floor(pixelLength / MINIMAP_ROUTE_SEGMENT_STEP_PX))
                local prevX = startX
                local prevY = startY
                for stepIndex = 1, steps do
                    local t = stepIndex / steps
                    local markerX = startX + dx * t
                    local markerY = startY + dy * t
                    local slot = AcquireSegmentSlot()
                    if not UpdateSegmentSlot(slot, prevX, prevY, markerX, markerY, segment.color or route.color or {}) then
                        minimapState.activeCount = minimapState.activeCount - 1
                    end
                    prevX = markerX
                    prevY = markerY
                end
            end
        end
    end

    TrimUnusedSegmentSlots()
end
